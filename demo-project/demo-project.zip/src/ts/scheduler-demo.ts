declare var $: any;

class schedulerDemo {

    constructor() {
        this.modalClose();
    }

    start() {
        const isDraggable = true;
        const isResizable = true;
        const $sc = $("#schedule").timeSchedule({
            startTime: "07:00", // schedule start time(HH:ii)
            endTime: "24:00",   // schedule end time(HH:ii)
            widthTime: 60 * 30,  // cell timestamp example 10 minutes
            timeLineY: 100,       // height(px)
            verticalScrollbar: 20,   // scrollbar (px)
            timeLineBorder: 2,   // border(top and bottom)
            bundleMoveWidth: 6,  // width to move all schedules to the right of the clicked time line cell
            draggable: isDraggable,
            resizable: isResizable,
            // 테스트 초기화 정보
            rows: {
                '0': {
                    title: 'ex0',
                    subtitle: 'Description',
                    schedule: [
                        {
                            start: '09:00',
                            end: '12:00',
                            text: 'ex0-1',
                            data: {}
                        },
                        {
                            start: '12:00',
                            end: '15:00',
                            text: 'ex0-2',
                            data: {}
                        }
                    ]
                },
                '1': {
                    title: 'ex1',
                    schedule: [
                        {
                            start: '15:00',
                            end: '18:00',
                            text: 'ex1-1',
                            data: {}
                        }
                    ]
                }
            },
            // 변화가 생겼을 때
            onChange: (node: any, data: any) => {
                console.log(data);
                console.log('change');
            },
            // 섹션 초기화했을 때
            onInitRow: (node: any, data: any) => {
                console.log('init');
            },
            // 추가되어있는 스케줄 클릭했을 때
            onClick: (node: any, data: any) => {
                var start = $(this).timeSchedule('formatTime', data.start);
                var end = $(this).timeSchedule('formatTime', data.end);
                this.modifyModal(data, start, end);
                console.log(data);
                const sectionTimeline = data.timeline;
                $('#sectionTimeline').val(sectionTimeline);

                // 정보를 가져올 때의 timeline은 스케쥴 순서별 timeline (왼쪽부터 0, 1, 2)
                console.log('timelineData', $(this).timeSchedule('timelineData'));
                console.log('scheduleData', $(this).timeSchedule('scheduleData'));
            },
            // 섹션 추가됐을 때
            onAppendRow: (node: any, data: any) => {
                console.log('onAppendRow');
            },
            // 스케줄 추가했을 때
            onAppendSchedule: (node: any, data: any) => {
                console.log('onAppendSchedule');
                if (data.data.class) {
                    node.addClass(data.data.class);
                }
                if (data.data.image) {
                    var $img = $('<div class="photo"><img></div>');
                    $img.find('img').attr('src', data.data.image);
                    node.prepend($img);
                    node.addClass('sc_bar_photo');
                }
                this.modalClose();
            },
            // 비어있는 스케줄러 클릭했을 때
            onScheduleClick: (node: any, time: any, timeline: any) => {
                var start = time;
                var end = $(this).timeSchedule('formatTime', $(this).timeSchedule('calcStringTime', time) + 3600);
                this.makeModal(start, end, timeline);
            },
        });

        $('#event_timelineData').on('click', function () {
            console.log($sc.timeSchedule('timelineData'));
        });

        $('#event_scheduleData').on('click', function () {
            console.log($sc.timeSchedule('scheduleData'));
        });

        // 수정하기 클릭
        $('.modify').on('click', () => {
            this.modifySchedule($sc);
        });

        // 취소 클릭
        $('.cancel').on('click', () => {
            this.modalClose();
        });

        // 만들기 클릭
        $('.make').on('click', () => {
            this.addSchedule($sc)
        });

        // 섹션 추가하기
        $('.add-section').on('click', () => {
            this.addSection($sc);
        });

        // 섹션 삭제하기
        $('.section-delete').on('click', () => {
            this.removeSection($sc);
        })

        $('#clear-logs').on('click', () => {
            $('#logs .table').empty();
        });

        // ajax 데이터 랜더링
        $('.ajax-data').on('click', ($event: any) => {
            $.ajax({url: './demo/' + $($event.target).attr('data-target')})
                .done((data: any) => {
                    console.log(data);
                    $sc.timeSchedule('setRows', data);
                });
        });

        $('.sc_data_scroll .timeline').on('click', ($event: any) => {
            console.log(1);
            this.sectionModal($($event.target).index(), $sc);
        })
    }

    // 섹션 삭제
    removeSection($sc: any) {
        const timeScheduleClone = JSON.parse(JSON.stringify($sc.timeSchedule('timelineData')));
        const timelineDataArr = new Array() as any;
        const timelineDataObj = new Object() as any;
        const sectionNum = Number($('#sectionTimeline').val());
        $.each(timeScheduleClone, (i: number, k: any) => {
            if (sectionNum !== i) {
                timelineDataArr.push(k);
                $.each(k.schedule, function(j: number, l: any) {
                    l.start = $sc.timeSchedule('formatTime', l.start);
                    l.end = $sc.timeSchedule('formatTime', l.end);
                })
            }
        });

        $.each(timelineDataArr, (i: number, k: any) => {
            timelineDataObj[i] = k;
        })

        console.log(timelineDataObj);
        $sc.timeSchedule('setRows', timelineDataObj);
        this.modalClose();
    }

    // 섹션 모달창
    sectionModal(index: number, $sc: any) {
        this.modal();
        $('.start').css('display', 'none');
        $('.end').css('display', 'none');
        $('.section-delete').css('display', 'inline-block');
        $('.section-modify').css('display', 'inline-block');
        $('#sectionTimeline').val(index);
    }

    // 스케쥴 수정
    modifySchedule($sc: any) {
        const timelineData = new Object() as any;
        const timeScheduleClone = JSON.parse(JSON.stringify($sc.timeSchedule('timelineData')));
        $.each(timeScheduleClone, (i: number, k: any) => {
            timelineData[i] = k;
            $.each(k.schedule, function(j: number, l: any) {
                l.start = $sc.timeSchedule('formatTime', l.start);
                l.end = $sc.timeSchedule('formatTime', l.end);
            })
        });
        const title = $('.title').val();
        // console.log('timelineData', $sc.timeSchedule('timelineData'));
        // console.log('scheduleData', $sc.timeSchedule('scheduleData'));
        // console.log(timelineData);
        // $sc.timeSchedule('resetRowData');
        // $sc.timeSchedule('setRows', timelineData);
        // $sc.timeSchedule('setRows', data);
    }

    // 스케줄 추가
    addSchedule($sc: any) {
        if (!$.trim($('.title').val()) || $('.title').val().length === 0) {
            return;
        }
        var newSchedule = {
            start: $('.start').val(),
            end: $('.end').val(),
            text: $('.title').val(),
            data: {
                class: ''
            }
        };
        $sc.timeSchedule('addSchedule', $('#sectionTimeline').val(), newSchedule);
    }

    // 색션추가
    addSection($sc: any) {
        var sectionName = $('.add-section').prev('input[type="text"]').val();
        var scheduleData = $sc.timeSchedule('timelineData');
        var sectionTimeline = scheduleData.length; // 이 timeline은 섹션 timeline(row's timeline);
        var newSectionObj = new Object() as any;
        newSectionObj.title = sectionName;
        $sc.timeSchedule('addRow', sectionTimeline, newSectionObj);
    }

    // 수정하기 모달 창
    modifyModal(data: any, start: any, end: any) {
        this.modal();
        $('.cancel').css('display', 'inline-block');
        $('.delete').css('display', 'inline-block');
        $('.modify').css('display', 'inline-block');
        $('.title').val(data.text);
        $('.start').val(start);
        $('.end').val(end);
        $('#scheduleTimeline').val(data.timeline);
    }

    // 만들기 모달 창
    makeModal(start: any, end: any, timeline: any) {
        this.modal();
        $('.make').css('display', 'inline-block');
        $('.modify').css('display', 'none');
        $('.start').val(start);
        $('.end').val(end);
        $('#sectionTimeline').val(timeline);
    }

    modal() {
        $('.modal-mask').css('display', 'table');
        $('body').css('overflow', 'hidden');
        $('.modal-wrapper').css('opacity', 1);
    }

    // 모달 창 닫기
    modalClose() {
        $('.title').val('');
        $('.modal-mask').css('display', 'none');
        $('body').css('overflow', 'initial');
        $('.modal-wrapper').css('opacity', 0);
        $('.modal-mask').find('input').val('');
        $('.modal-mask').find('button').css('display', 'none');
    }
}

(window as any).schedulerApp = new schedulerDemo();
